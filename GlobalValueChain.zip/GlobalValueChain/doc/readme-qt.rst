GlobalValueChain-Qt: Qt5 GUI for GlobalValueChain
===============================

Linux
-------
https://github.com/GlobalValueChaindev/GlobalValueChain/blob/master/doc/build-unix.md

Windows
--------
https://github.com/GlobalValueChaindev/GlobalValueChain/blob/master/doc/build-msw.md

Mac OS X
--------
https://github.com/GlobalValueChaindev/GlobalValueChain/blob/master/doc/build-osx.md
